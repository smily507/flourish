# Flourish

A wellness storefront for women navigating menopause — affiliate shop, digital journal, and an in-page advisor named Flo.

## Run locally
```
npm install
npm run dev
```

## Before you go live
Swap the placeholder links in these two files with your real ones:
- `src/pages/Shop.jsx` — Amazon UK / iHerb affiliate links
- `src/pages/Journal.jsx` — your Gumroad journal link

## Deploy
See the deployment steps Claude walked you through in chat: push this folder to GitHub, then import the repo in Vercel.
