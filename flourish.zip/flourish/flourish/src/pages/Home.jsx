import { Link } from 'react-router-dom'
import PhaseArc from '../components/PhaseArc'
import FloAdvisor from '../components/FloAdvisor'

export default function Home() {
  return (
    <div>
      <section className="container" style={{ paddingTop: 'var(--space-5)', paddingBottom: 'var(--space-4)' }}>
        <p className="eyebrow">A guide through the second spring</p>
        <h1 style={{ fontSize: 'clamp(2.4rem, 5vw, 4rem)', maxWidth: '740px', marginTop: '0.6rem' }}>
          Menopause isn't an ending. It's a transition worth navigating well.
        </h1>
        <p style={{ maxWidth: '520px', marginTop: 'var(--space-2)', fontSize: '1.05rem', opacity: 0.85 }}>
          Flourish is honest guidance, tested products, and a daily journal — built by someone who's living this transition too.
        </p>
        <div style={{ display: 'flex', gap: '1rem', marginTop: 'var(--space-3)' }}>
          <Link to="/shop" className="btn-primary">Explore the Shop</Link>
          <Link to="/journal" className="btn-secondary">Get the Journal</Link>
        </div>
        <PhaseArc height={140} />
      </section>

      <section className="container" style={{ paddingBottom: 'var(--space-6)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-5)', alignItems: 'start' }}>
          <div>
            <p className="eyebrow">Talk it through</p>
            <h2 style={{ fontSize: '1.9rem', marginTop: '0.5rem' }}>Meet Flo</h2>
            <p style={{ marginTop: '0.8rem', opacity: 0.85 }}>
              Not sure where to start? Flo can point you toward what's helped other women with sleep, hot flashes, mood, and more.
            </p>
          </div>
          <FloAdvisor />
        </div>
      </section>
    </div>
  )
}
