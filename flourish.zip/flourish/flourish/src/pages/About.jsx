export default function About() {
  return (
    <div className="container" style={{ paddingTop: 'var(--space-5)', paddingBottom: 'var(--space-6)', maxWidth: '680px' }}>
      <p className="eyebrow">Why Flourish exists</p>
      <h1 style={{ fontSize: '2.4rem', marginTop: '0.5rem' }}>I'm building this from the inside of it.</h1>
      <p style={{ marginTop: 'var(--space-3)', opacity: 0.85, fontSize: '1.05rem' }}>
        I'm a retired teacher going through this transition myself, and I got tired of wellness content that treats menopause like a problem to be fixed quietly. Flourish is the resource I wish I'd had — practical, tested, and made by someone in it, not looking at it from the outside.
      </p>
      <p style={{ marginTop: 'var(--space-2)', opacity: 0.85, fontSize: '1.05rem' }}>
        Every product in the Shop is picked for a specific symptom. The Journal is the tool I actually use to track my own days. And Flo is here so you're not doing the research alone at 2am.
      </p>
    </div>
  )
}
