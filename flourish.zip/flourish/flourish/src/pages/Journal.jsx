export default function Journal() {
  return (
    <div className="container" style={{ paddingTop: 'var(--space-5)', paddingBottom: 'var(--space-6)' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 0.9fr', gap: 'var(--space-5)', alignItems: 'center' }}>
        <div>
          <p className="eyebrow">The Flourish Journal</p>
          <h1 style={{ fontSize: '2.6rem', marginTop: '0.5rem' }}>Track it. Understand it. Move through it.</h1>
          <p style={{ marginTop: 'var(--space-2)', opacity: 0.85, maxWidth: '480px' }}>
            A day-by-day digital journal built specifically for perimenopause and menopause — symptom tracking, mood check-ins, and prompts that help you spot patterns your doctor will actually want to see.
          </p>
          <a
            href="https://gumroad.com/YOUR-JOURNAL-LINK-HERE"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
            style={{ marginTop: 'var(--space-3)', display: 'inline-flex' }}
          >
            Get the Journal on Gumroad
          </a>
        </div>
        <div style={{
          background: 'var(--plum-deep)', borderRadius: '10px', aspectRatio: '4/5',
          display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 'var(--space-4)',
        }}>
          <div style={{ textAlign: 'center', color: 'var(--paper)' }}>
            <p className="eyebrow" style={{ color: 'var(--gold-soft)' }}>Digital Download</p>
            <h2 style={{ color: 'var(--paper)', fontSize: '1.8rem', marginTop: '0.6rem', fontStyle: 'italic' }}>
              The Flourish Journal
            </h2>
          </div>
        </div>
      </div>
    </div>
  )
}
