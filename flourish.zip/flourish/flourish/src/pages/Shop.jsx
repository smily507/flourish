const products = [
  { name: 'Cooling Mattress Topper', store: 'Amazon UK', category: 'Sleep', link: 'https://www.amazon.co.uk/YOUR-AFFILIATE-LINK-HERE' },
  { name: 'Magnesium Glycinate', store: 'iHerb', category: 'Sleep & Mood', link: 'https://www.iherb.com/YOUR-AFFILIATE-LINK-HERE' },
  { name: 'Moisture-Wicking Sleepwear', store: 'Amazon UK', category: 'Hot Flashes', link: 'https://www.amazon.co.uk/YOUR-AFFILIATE-LINK-HERE' },
  { name: 'Personal Desk Fan', store: 'Amazon UK', category: 'Hot Flashes', link: 'https://www.amazon.co.uk/YOUR-AFFILIATE-LINK-HERE' },
  { name: 'Omega-3 Fish Oil', store: 'iHerb', category: 'Mood', link: 'https://www.iherb.com/YOUR-AFFILIATE-LINK-HERE' },
  { name: 'Plant-Based Protein Powder', store: 'iHerb', category: 'Metabolism', link: 'https://www.iherb.com/YOUR-AFFILIATE-LINK-HERE' },
]

export default function Shop() {
  return (
    <div className="container" style={{ paddingTop: 'var(--space-5)', paddingBottom: 'var(--space-6)' }}>
      <p className="eyebrow">Tested & trusted</p>
      <h1 style={{ fontSize: '2.6rem', marginTop: '0.5rem' }}>The Shop</h1>
      <p style={{ maxWidth: '560px', marginTop: '0.8rem', opacity: 0.85 }}>
        Every product here is something recommended for a specific symptom, not a generic wellness haul. Swap in your real links whenever you're ready.
      </p>

      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))',
        gap: 'var(--space-3)', marginTop: 'var(--space-4)',
      }}>
        {products.map((p) => (
          <a
            key={p.name}
            href={p.link}
            target="_blank"
            rel="noopener noreferrer sponsored"
            style={{
              display: 'block', background: 'var(--paper-warm)',
              border: '1px solid rgba(42,33,25,0.1)', borderRadius: '8px',
              padding: 'var(--space-3)', transition: 'transform 0.15s ease, border-color 0.15s ease',
            }}
            onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-3px)'}
            onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}
          >
            <span className="eyebrow">{p.category}</span>
            <h3 style={{ fontSize: '1.15rem', marginTop: '0.4rem' }}>{p.name}</h3>
            <p style={{ fontSize: '0.85rem', opacity: 0.65, marginTop: '0.4rem' }}>via {p.store} →</p>
          </a>
        ))}
      </div>

      <p style={{ fontSize: '0.8rem', opacity: 0.6, marginTop: 'var(--space-4)' }}>
        As an Amazon and iHerb associate, Flourish earns from qualifying purchases at no extra cost to you.
      </p>
    </div>
  )
}
