import { useState } from 'react'

// NOTE: This is a lightweight placeholder for "Flo" — canned, keyword-matched
// responses so the feature is live and usable today. When you're ready to
// make Flo a real AI advisor, this is the one component that needs a call to
// a backend (e.g. a Vercel serverless function holding your Anthropic API
// key) instead of the local matchResponse() function below.
const TIPS = [
  { keys: ['sleep', 'insomnia', 'wake'], reply: "Night sweats disrupting sleep are common. A lot of women in the community find a cooling mattress topper and magnesium glycinate before bed helpful — both linked in the Shop." },
  { keys: ['hot flash', 'flush', 'heat'], reply: "For hot flashes: layering fabrics, a small personal fan, and cutting back on caffeine after noon are the three most-reported wins. Check the Shop for a few reader-tested picks." },
  { keys: ['mood', 'anxious', 'irritable'], reply: "Mood swings during this transition are real and hormonal, not a character flaw. Many find daily journaling helps spot patterns — that's exactly what the Flourish Journal is built for." },
  { keys: ['weight', 'metabolism'], reply: "Metabolism shifts are common in perimenopause. Strength training and protein-forward meals tend to matter more now than they did in your 30s." },
  { keys: ['journal', 'track'], reply: "The Flourish Journal is designed to help you track symptoms day-to-day so you and your doctor can spot patterns together." },
]

function matchResponse(input) {
  const lower = input.toLowerCase()
  const hit = TIPS.find(t => t.keys.some(k => lower.includes(k)))
  return hit ? hit.reply : "That's a great question to bring to your doctor — but here's what other women in this stage often find helpful: start by tracking it in the Flourish Journal so you notice patterns over time."
}

export default function FloAdvisor() {
  const [messages, setMessages] = useState([
    { from: 'flo', text: "Hi, I'm Flo. Ask me about sleep, hot flashes, mood, or anything else on your mind today." }
  ])
  const [input, setInput] = useState('')

  function send() {
    if (!input.trim()) return
    const userMsg = { from: 'user', text: input }
    const reply = { from: 'flo', text: matchResponse(input) }
    setMessages(m => [...m, userMsg, reply])
    setInput('')
  }

  return (
    <div style={{
      background: 'var(--paper-warm)',
      border: '1px solid rgba(42,33,25,0.12)',
      borderRadius: '8px',
      padding: 'var(--space-3)',
      maxWidth: '480px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: 'var(--space-2)' }}>
        <div style={{
          width: 36, height: 36, borderRadius: '50%',
          background: 'linear-gradient(135deg, var(--rust), var(--gold))',
        }} />
        <div>
          <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>Flo</div>
          <div style={{ fontSize: '0.75rem', opacity: 0.6 }}>Your wellness advisor</div>
        </div>
      </div>

      <div style={{ maxHeight: 220, overflowY: 'auto', marginBottom: 'var(--space-2)', display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
        {messages.map((m, i) => (
          <div key={i} style={{
            alignSelf: m.from === 'flo' ? 'flex-start' : 'flex-end',
            background: m.from === 'flo' ? 'var(--paper)' : 'var(--plum-deep)',
            color: m.from === 'flo' ? 'var(--ink)' : 'var(--paper)',
            padding: '0.6rem 0.9rem',
            borderRadius: '10px',
            fontSize: '0.88rem',
            maxWidth: '85%',
          }}>
            {m.text}
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: '0.5rem' }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && send()}
          placeholder="Ask Flo something..."
          style={{
            flex: 1, padding: '0.6rem 0.8rem', borderRadius: '6px',
            border: '1px solid rgba(42,33,25,0.2)', fontSize: '0.88rem',
            fontFamily: 'var(--font-body)',
          }}
        />
        <button onClick={send} className="btn-primary" style={{ padding: '0.6rem 1rem' }}>Ask</button>
      </div>
    </div>
  )
}
