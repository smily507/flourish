export default function Footer() {
  return (
    <footer style={{ background: 'var(--plum-deep)', color: 'var(--paper)', marginTop: 'var(--space-6)' }}>
      <div className="container" style={{
        padding: 'var(--space-4) var(--space-3)',
        display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1.5rem',
      }}>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: '1.25rem' }}>Flourish</div>
          <p style={{ fontSize: '0.85rem', opacity: 0.7, maxWidth: '320px', marginTop: '0.5rem' }}>
            A guide through the second spring — honest picks, a daily journal, and someone in your corner.
          </p>
        </div>
        <div style={{ fontSize: '0.85rem', opacity: 0.7 }}>
          <p style={{ margin: 0 }}>As an Amazon &amp; iHerb associate, Flourish earns from qualifying purchases.</p>
          <p style={{ margin: '0.4rem 0 0' }}>© {new Date().getFullYear()} Flourish</p>
        </div>
      </div>
    </footer>
  )
}
