import { NavLink } from 'react-router-dom'

const links = [
  { to: '/', label: 'Home', end: true },
  { to: '/shop', label: 'Shop' },
  { to: '/journal', label: 'Journal' },
  { to: '/about', label: 'About' },
]

export default function Nav() {
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 50,
      background: 'var(--paper)',
      borderBottom: '1px solid rgba(42,33,25,0.1)',
    }}>
      <div className="container" style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        height: '76px',
      }}>
        <NavLink to="/" style={{
          fontFamily: 'var(--font-display)', fontSize: '1.5rem',
          color: 'var(--plum-deep)', fontStyle: 'italic',
        }}>
          Flourish
        </NavLink>
        <nav style={{ display: 'flex', gap: '2rem', alignItems: 'center' }}>
          {links.map(l => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              style={({ isActive }) => ({
                fontSize: '0.92rem',
                fontWeight: 500,
                color: isActive ? 'var(--rust)' : 'var(--plum-deep)',
                borderBottom: isActive ? '2px solid var(--rust)' : '2px solid transparent',
                paddingBottom: '4px',
              })}
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  )
}
