// Signature motif: a horizon line moving from dusk (plum) through to gold —
// menopause reframed as a transition of light, not a decline.
export default function PhaseArc({ height = 220 }) {
  return (
    <svg className="phase-arc" viewBox="0 0 1000 220" preserveAspectRatio="none" style={{ height }} aria-hidden="true">
      <defs>
        <linearGradient id="dusk-to-gold" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#3D2740" />
          <stop offset="45%" stopColor="#A8552E" />
          <stop offset="100%" stopColor="#C9A227" />
        </linearGradient>
      </defs>
      <path
        d="M0,180 C 200,60 350,200 500,110 C 650,30 800,150 1000,40"
        fill="none"
        stroke="url(#dusk-to-gold)"
        strokeWidth="3"
        strokeLinecap="round"
      />
      <circle cx="1000" cy="40" r="7" fill="#C9A227" />
    </svg>
  )
}
